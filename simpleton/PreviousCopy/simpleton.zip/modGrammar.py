#
# modGrammar.py
#

def addWord(mw):

    print('Adding ' + mw + ' to gramaar')

    return
